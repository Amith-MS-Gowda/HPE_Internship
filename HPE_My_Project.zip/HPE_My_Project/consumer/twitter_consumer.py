# tweet_consumer.py

from kafka import KafkaConsumer
from elasticsearch import Elasticsearch
import json
import os
import logging

logging.basicConfig(level=logging.INFO)

# Config
KAFKA_TOPIC = os.getenv('KAFKA_TOPIC', 'twitter-stream')
KAFKA_BROKER = os.getenv('KAFKA_BROKER', 'localhost:9092')
ELASTIC_HOST = os.getenv('ELASTIC_HOST', 'http://localhost:9222')
ELASTIC_INDEX = os.getenv('ELASTIC_INDEX', 'twitter-index')

# Initialize Kafka consumer
consumer = KafkaConsumer(
    KAFKA_TOPIC,
    bootstrap_servers=[KAFKA_BROKER],
    value_deserializer=lambda m: json.loads(m.decode('utf-8')),
    auto_offset_reset='earliest',
    enable_auto_commit=True,
    group_id='twitter-consumer-group'
)

# Initialize Elasticsearch
es = Elasticsearch(ELASTIC_HOST)

logging.info("Started Kafka consumer...")

for message in consumer:
    tweet = message.value
    logging.info(f"Received tweet: {tweet}")

    # Optional: Customize how you index the tweet
    es.index(index=ELASTIC_INDEX, body=tweet)
    logging.info("Tweet indexed to Elasticsearch")
