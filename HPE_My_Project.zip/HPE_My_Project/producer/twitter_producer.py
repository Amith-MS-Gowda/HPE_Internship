import tweepy
from kafka import KafkaProducer
import json

# Twitter Bearer Token
BEARER_TOKEN = 'AAAAAAAAAAAAAAAAAAAAAP4o2gEAAAAA1uxUIvMFSHTmi3UTH2QDEiNQvcE%3DzZ6WRql85t5V0KjolNawMhIEnWwBedVstDfBEHOhAZWKSCJtTN'

# Kafka setup
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# Stream Listener
class TweetStreamer(tweepy.StreamingClient):
    def on_tweet(self, tweet):
        data = {'id': tweet.id, 'text': tweet.text}
        producer.send('twitter-stream', value=data)
        print(f"Sent tweet: {tweet.text}")

# Start streaming
stream = TweetStreamer(BEARER_TOKEN)
stream.add_rules(tweepy.StreamRule("technology OR AI OR science"))
stream.filter(tweet_fields=["text"])
